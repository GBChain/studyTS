


export function isStringEmpty(str: string): boolean {
    return str.trim().length === 0;
  }


  