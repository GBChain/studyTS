
export interface CurrentUser {
    user: {
        id: number,
        mobile: string,
        name: string
        gender: string,
        id_number: string
        email: string,
        department: string
        company: string,
        job_title: string
        date_of_birth: number
    },
    roles: string[], //权限
    token: string
}