// import { Db, MongoClient } from "mongodb";
// import mongoose from 'mongoose';

const mongoose = require('mongoose');


export class Global {
   
    static async initDb() {
         const uri = 'mongodb://guoyibo:QQqq421380456@127.0.0.1:27017/EGM';
        
        mongoose.set('strictQuery', false); //去掉mongoose 7的一个警告
        mongoose.connect(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        // keepAlive: true
        })
        .then(() => {
            console.log('数据库已经连接1');
            // 在这里执行数据库操作

        })
        .catch((error: Error) => {
            console.error('Error connecting to MongoDB:', error);
        });


        mongoose.connection.once('connected', () => {
            console.log('数据库已经连接2');
            // 在这里执行一次性的操作

          });

        mongoose.connection.once('close', () => {
            console.log('数据库断开了');
          });  
    


    }





}