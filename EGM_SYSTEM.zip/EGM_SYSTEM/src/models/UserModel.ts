// import { Schema } from "mongoose";

var mongoose = require('mongoose');
const mongooseSequence = require('mongoose-sequence-sequential');

var Schema = mongoose.Schema;
 
var userSchema = new Schema(
    {
    uid: { type: Number, unique: true },
    mobile: String,
    name: String,
    gender: Number,
    id_number: String, //身份证号
    email: String,
    department: String,
    company: String,
    job_title: String,
    date_of_birth: Date  //生日
    },
    { timestamps:true } //创建日期和更新日期
);

userSchema.plugin(mongooseSequence(mongoose), { inc_field: 'uid' });
export const userModel = mongoose.model('users', userSchema);

// module.exports = userModel; //这种需要用require来调用