export interface ReqLogin {
    mobile: string, //手机号需要客户端进行验证,服务端也要验证
    code: string  //服务端随机产生的
}

export interface ResLogin {
    user: {
        uid: number,
        mobile: string,
        name: string,
        gender: number,
        id_number: string,
        email?: string,
        department: string,
        company: string,
        job_title?: string,
        date_of_birth?: Date
    }
}