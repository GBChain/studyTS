export interface ReqRegister {
    mobile: string,
    name: string,
    gender: number,
    id_number: string,
    email?: string,
    department: string,
    company: string,
    job_title?: string, //职位
    date_of_birth?: Date  //生日
}

export interface ResRegister {
    user: {
        uid: number,
        mobile: string,
        name: string,
        gender: number,
        id_number: string,
        email?: string,
        department: string,
        company: string,
        job_title?: string,
        date_of_birth?: Date
    }
}