import { ServiceProto } from 'tsrpc-proto';
import { ReqAddData, ResAddData } from './PtlAddData';
import { ReqGetData, ResGetData } from './PtlGetData';
import { ReqLogin, ResLogin } from './user/PtlLogin';
import { ReqRegister, ResRegister } from './user/PtlRegister';

export interface ServiceType {
    api: {
        "AddData": {
            req: ReqAddData,
            res: ResAddData
        },
        "GetData": {
            req: ReqGetData,
            res: ResGetData
        },
        "user/Login": {
            req: ReqLogin,
            res: ResLogin
        },
        "user/Register": {
            req: ReqRegister,
            res: ResRegister
        }
    },
    msg: {

    }
}

export const serviceProto: ServiceProto<ServiceType> = {
    "version": 6,
    "services": [
        {
            "id": 0,
            "name": "AddData",
            "type": "api"
        },
        {
            "id": 1,
            "name": "GetData",
            "type": "api"
        },
        {
            "id": 2,
            "name": "user/Login",
            "type": "api"
        },
        {
            "id": 3,
            "name": "user/Register",
            "type": "api"
        }
    ],
    "types": {
        "PtlAddData/ReqAddData": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "content",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "PtlAddData/ResAddData": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "time",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "PtlGetData/ReqGetData": {
            "type": "Interface"
        },
        "PtlGetData/ResGetData": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "data",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Interface",
                            "properties": [
                                {
                                    "id": 0,
                                    "name": "content",
                                    "type": {
                                        "type": "String"
                                    }
                                },
                                {
                                    "id": 1,
                                    "name": "time",
                                    "type": {
                                        "type": "Date"
                                    }
                                }
                            ]
                        }
                    }
                }
            ]
        },
        "user/PtlLogin/ReqLogin": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "mobile",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "code",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "user/PtlLogin/ResLogin": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "user",
                    "type": {
                        "type": "Interface",
                        "properties": [
                            {
                                "id": 0,
                                "name": "id",
                                "type": {
                                    "type": "Number"
                                }
                            },
                            {
                                "id": 1,
                                "name": "mobile",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 2,
                                "name": "name",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 3,
                                "name": "gender",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 4,
                                "name": "id_number",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 5,
                                "name": "email",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 6,
                                "name": "department",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 7,
                                "name": "company",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 8,
                                "name": "job_title",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 9,
                                "name": "date_of_birth",
                                "type": {
                                    "type": "Number"
                                }
                            }
                        ]
                    }
                }
            ]
        },
        "user/PtlRegister/ReqRegister": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "mobile",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 10,
                    "name": "name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 11,
                    "name": "gender",
                    "type": {
                        "type": "Number"
                    }
                },
                {
                    "id": 12,
                    "name": "id_number",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 13,
                    "name": "email",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 14,
                    "name": "department",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 15,
                    "name": "company",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 16,
                    "name": "job_title",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 17,
                    "name": "date_of_birth",
                    "type": {
                        "type": "Date"
                    },
                    "optional": true
                }
            ]
        },
        "user/PtlRegister/ResRegister": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "user",
                    "type": {
                        "type": "Interface",
                        "properties": [
                            {
                                "id": 10,
                                "name": "uid",
                                "type": {
                                    "type": "Number"
                                }
                            },
                            {
                                "id": 1,
                                "name": "mobile",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 11,
                                "name": "name",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 12,
                                "name": "gender",
                                "type": {
                                    "type": "Number"
                                }
                            },
                            {
                                "id": 13,
                                "name": "id_number",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 14,
                                "name": "email",
                                "type": {
                                    "type": "String"
                                },
                                "optional": true
                            },
                            {
                                "id": 15,
                                "name": "department",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 16,
                                "name": "company",
                                "type": {
                                    "type": "String"
                                }
                            },
                            {
                                "id": 17,
                                "name": "job_title",
                                "type": {
                                    "type": "String"
                                },
                                "optional": true
                            },
                            {
                                "id": 18,
                                "name": "date_of_birth",
                                "type": {
                                    "type": "Date"
                                },
                                "optional": true
                            }
                        ]
                    }
                }
            ]
        }
    }
};