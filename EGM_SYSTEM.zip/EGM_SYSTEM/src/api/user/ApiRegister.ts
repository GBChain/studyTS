import { ApiCall } from "tsrpc";
import { ReqRegister, ResRegister } from "../../shared/protocols/user/PtlRegister";
import { Global } from "../../models/Global";
import mongoose from "mongoose";
import { userModel} from "../../models/UserModel"
import { Document } from "mongodb";
import { isStringEmpty } from "../../../util/utils";



export async function ApiRegister (call: ApiCall<ReqRegister, ResRegister>) {
    
    //对格式进行检查 
    //TODO:这里需要更详细
    if(!(!isStringEmpty(call.req.name) 
      && !isStringEmpty(call.req.mobile ) 
      && !isStringEmpty(call.req.id_number) 
      && !isStringEmpty(call.req.department) 
      && !isStringEmpty(call.req.company)
      && call.req.gender > 0
      )){
       call.error('有数据没有填'); 
       return;
     }

    const savedDoc = await userModel.create({
      name: call.req.name,
      mobile: call.req.mobile,
      gender: call.req.gender,
      id_number: call.req.id_number,
      email: call.req.email,
      department: call.req.department,
      company: call.req.company,
      job_title: call.req.job_title,
      date_of_birth: call.req.date_of_birth,
    }) 
    .then((savedDoc: Document) => {

    // 返回成功的值
    call.succ({
      user: {
        uid: savedDoc.uid, // 获取自动生成的 uid
        name: savedDoc.name,
        mobile: savedDoc.mobile,
        gender: savedDoc.gender,
        id_number: savedDoc.id_number,
        email: savedDoc.email,
        department: savedDoc.department,
        company: savedDoc.company,
        job_title: savedDoc.job_title,
        date_of_birth: savedDoc.date_of_birth,
      },
    });

      console.log('1.插入成功:', savedDoc);
    })
    .catch((error: any) => {
      console.error('2.插入失败', error);
    });
}