import { LoginInfo } from "../models/LoginInfo";




const jwt = require('jsonwebtoken');
const secretKey = 'QQqq421380123..';


export class RequestUtil {


    createSsoToken(uid: number): string {
        const token = jwt.sign({ uid }, secretKey, { expiresIn: '30d' }); // 设置过期时间为小时
        console.log('JWT:', token);
        return token;
    }


    parseSSO(ssoToken: string): LoginInfo | null {
        try {
            // 解析 SSO Token
            const decoded: any = jwt.verify(ssoToken, secretKey);
        
            // 根据解析的数据创建 LoginInfo 对象
            const loginInfo: LoginInfo = {
              uid: decoded.userId,
              username: decoded.username,
              email: decoded.email,
              // 根据需要添加其他字段...
            };
        
            return loginInfo;
          } catch (error) {
            // 解析失败，token 无效或过期
            console.error('SSO Token verification failed:', error.message);
            return null;
          }
    }


}

