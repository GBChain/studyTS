import * as path from "path";
import { HttpServer } from "tsrpc";
import { serviceProto } from "./shared/protocols/serviceProto";
import { Global } from "./models/Global";
import { EncryptUtil } from "../util/EncryptUtil";

// Create the Server
const server = new HttpServer(serviceProto, {
    port: 3000,
    // Remove this to use binary mode (remove from the client too)
    json: true
});

// 加密
server.flows.preSendDataFlow.push(v => {
    if(v.data instanceof Uint8Array){
        v.data = EncryptUtil.encrypt(v.data);
    }
    return v;
});
// 解密
server.flows.preRecvDataFlow.push(v => {
    if(v.data instanceof Uint8Array){
        v.data = EncryptUtil.decrypt(v.data);
    }   
    return v;
})

// Initialize before server start
async function init() {
    // Auto implement APIs
    await server.autoImplementApi(path.resolve(__dirname, 'api'));
    // 在服务启动前先连接好数据库
    await Global.initDb();
    
};

// Entry function
async function main() {
    await init();
    await server.start();
};
main();